'use client'

import { useEffect, useState, useMemo } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { Order } from '@/lib/supabase'

interface Stats {
  totalProducts: number
  totalOrders: number
  pendingOrders: number
  totalRevenue: number
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats>({ totalProducts: 0, totalOrders: 0, pendingOrders: 0, totalRevenue: 0 })
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [chartView, setChartView] = useState<'revenue' | 'orders'>('revenue')

  useEffect(() => {
    Promise.all([
      fetch('/api/admin/stats').then(r => r.json()).catch(() => null),
      fetch('/api/admin/orders').then(r => r.json()).catch(() => []),
    ]).then(([statsData, ordersData]) => {
      if (statsData) setStats(statsData)
      setOrders(ordersData || [])
      setLoading(false)
    })
  }, [])

  const monthlyData = useMemo(() => {
    const months: Record<string, { revenue: number; count: number }> = {}
    const now = new Date()
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const key = d.toLocaleString('en-US', { month: 'short', year: '2-digit' })
      months[key] = { revenue: 0, count: 0 }
    }

    orders.filter(o => o.status === 'delivered').forEach(o => {
      const d = new Date(o.created_at)
      const key = d.toLocaleString('en-US', { month: 'short', year: '2-digit' })
      if (months[key]) {
        months[key].revenue += o.total
        months[key].count++
      }
    })

    return Object.entries(months).map(([month, data]) => ({ month, ...data }))
  }, [orders])

  const maxRevenue = Math.max(...monthlyData.map(m => m.revenue), 1)
  const maxCount = Math.max(...monthlyData.map(m => m.count), 1)

  const topProducts = useMemo(() => {
    const map: Record<string, { name: string; qty: number; revenue: number; image?: string }> = {}
    orders.filter(o => o.status === 'delivered').forEach(o => {
      o.items?.forEach((item: any) => {
        const key = item.name || 'Unknown'
        if (!map[key]) map[key] = { name: key, qty: 0, revenue: 0, image: item.image }
        map[key].qty += item.quantity || 1
        map[key].revenue += (item.price || 0) * (item.quantity || 1)
      })
    })
    return Object.values(map).sort((a, b) => b.revenue - a.revenue).slice(0, 5)
  }, [orders])

  const recentOrders = useMemo(() => {
    return [...orders].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()).slice(0, 5)
  }, [orders])

  const avgOrderValue = orders.length > 0 ? stats.totalRevenue / orders.length : 0

  if (loading) return (
    <div className="animate-pulse space-y-6 p-2">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => <div key={i} className="h-28 bg-[#F3F5F8] rounded-2xl" />)}
      </div>
    </div>
  )

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="p-2 space-y-6">

      {/* Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-5 border border-[#E5E7EB] shadow-sm">
          <p className="text-[#9CA3AF] text-xs uppercase tracking-wider mb-1">Total Products</p>
          <p className="text-3xl font-bold text-[#1A1A1A]">{stats.totalProducts}</p>
        </div>
        <div className="bg-white rounded-2xl p-5 border border-[#E5E7EB] shadow-sm">
          <p className="text-[#9CA3AF] text-xs uppercase tracking-wider mb-1">Total Orders</p>
          <p className="text-3xl font-bold text-[#1A1A1A]">{stats.totalOrders}</p>
        </div>
        <div className="bg-white rounded-2xl p-5 border border-[#E5E7EB] shadow-sm">
          <p className="text-[#9CA3AF] text-xs uppercase tracking-wider mb-1">Pending</p>
          <p className="text-3xl font-bold text-amber-500">{stats.pendingOrders}</p>
        </div>
        <div className="bg-white rounded-2xl p-5 border border-[#E5E7EB] shadow-sm">
          <p className="text-[#9CA3AF] text-xs uppercase tracking-wider mb-1">Revenue</p>
          <p className="text-3xl font-bold text-[#8BA4B8]">{stats.totalRevenue.toLocaleString()} <span className="text-sm font-medium">EGP</span></p>
        </div>
      </div>

      {/* Middle Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-[#E5E7EB] shadow-sm">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-[family-name:var(--font-playfair)] text-[#1A1A1A]">Monthly Overview</h3>
            <div className="flex gap-1">
              <button onClick={() => setChartView('revenue')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${chartView === 'revenue' ? 'bg-[#8BA4B8] text-white' : 'bg-[#F3F5F8] text-[#6B7280] hover:bg-[#E5E7EB]'}`}>
                Revenue
              </button>
              <button onClick={() => setChartView('orders')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${chartView === 'orders' ? 'bg-[#8BA4B8] text-white' : 'bg-[#F3F5F8] text-[#6B7280] hover:bg-[#E5E7EB]'}`}>
                Orders
              </button>
            </div>
          </div>
          <div className="flex items-end gap-3 h-48">
            {monthlyData.map((m) => (
              <div key={m.month} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                <span className="text-[10px] text-[#9CA3AF] font-medium">
                  {chartView === 'revenue' ? `${(m.revenue / 1000).toFixed(0)}k` : m.count}
                </span>
                <div
                  className="w-full rounded-lg bg-gradient-to-t from-[#8BA4B8] to-[#8BA4B8]/60 transition-all duration-500 hover:opacity-80 cursor-pointer"
                  style={{ height: `${Math.max((chartView === 'revenue' ? m.revenue / maxRevenue : m.count / maxCount) * 100, 4)}%` }}
                />
                <span className="text-[10px] text-[#6B7280] mt-1">{m.month}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Top Products */}
        <div className="bg-white rounded-2xl p-6 border border-[#E5E7EB] shadow-sm">
          <h3 className="text-lg font-[family-name:var(--font-playfair)] text-[#1A1A1A] mb-4">Top Products</h3>
          {topProducts.length === 0 ? (
            <p className="text-[#9CA3AF] text-sm">No sales yet</p>
          ) : (
            <div className="space-y-3">
              {topProducts.map((p, i) => (
                <div key={p.name} className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-full bg-[#8BA4B8]/10 text-[#8BA4B8] text-xs font-bold flex items-center justify-center shrink-0">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-[#1A1A1A] truncate">{p.name}</p>
                    <p className="text-xs text-[#6B7280]">{p.qty} sold · {p.revenue.toLocaleString()} EGP</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Bottom Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <div className="bg-white rounded-2xl p-6 border border-[#E5E7EB] shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-[family-name:var(--font-playfair)] text-[#1A1A1A]">Recent Orders</h3>
            <Link href="/admin/orders" className="text-xs text-[#8BA4B8] hover:underline font-medium">View all</Link>
          </div>
          {recentOrders.length === 0 ? (
            <p className="text-[#9CA3AF] text-sm">No orders yet</p>
          ) : (
            <div className="space-y-2">
              {recentOrders.map(o => {
                const statusColors: Record<string, string> = {
                  pending: 'bg-amber-100 text-amber-700', confirmed: 'bg-sky-100 text-sky-700',
                  preparing: 'bg-violet-100 text-violet-700', shipped: 'bg-orange-100 text-orange-700',
                  out_for_delivery: 'bg-indigo-100 text-indigo-700', delivered: 'bg-emerald-100 text-emerald-700',
                  cancelled: 'bg-rose-100 text-rose-700',
                }
                return (
                  <div key={o.id} className="flex items-center justify-between py-2 border-b border-[#F0F0F0] last:border-0">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-[#1A1A1A] truncate">{o.customer_name}</p>
                      <p className="text-xs text-[#6B7280]">#{o.id.slice(0, 8)}</p>
                    </div>
                    <div className="text-right flex items-center gap-3">
                      <span className="text-sm font-semibold text-[#8BA4B8]">{o.total.toLocaleString()} EGP</span>
                      <span className={`px-2 py-0.5 text-[10px] font-semibold rounded-full ${statusColors[o.status] || 'bg-gray-100 text-gray-600'}`}>
                        {o.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>

        {/* Quick Stats */}
        <div className="bg-white rounded-2xl p-6 border border-[#E5E7EB] shadow-sm">
          <h3 className="text-lg font-[family-name:var(--font-playfair)] text-[#1A1A1A] mb-4">Quick Stats</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-[#F8F9FB] rounded-xl p-4">
              <p className="text-[#9CA3AF] text-xs uppercase tracking-wider">Avg Order Value</p>
              <p className="text-xl font-bold text-[#1A1A1A] mt-1">{avgOrderValue.toLocaleString(undefined, { maximumFractionDigits: 0 })} EGP</p>
            </div>
            <div className="bg-[#F8F9FB] rounded-xl p-4">
              <p className="text-[#9CA3AF] text-xs uppercase tracking-wider">Delivered</p>
              <p className="text-xl font-bold text-emerald-600 mt-1">{orders.filter(o => o.status === 'delivered').length}</p>
            </div>
            <div className="bg-[#F8F9FB] rounded-xl p-4">
              <p className="text-[#9CA3AF] text-xs uppercase tracking-wider">Cancelled</p>
              <p className="text-xl font-bold text-rose-500 mt-1">{orders.filter(o => o.status === 'cancelled').length}</p>
            </div>
            <div className="bg-[#F8F9FB] rounded-xl p-4">
              <p className="text-[#9CA3AF] text-xs uppercase tracking-wider">Conversion</p>
              <p className="text-xl font-bold text-[#1A1A1A] mt-1">
                {stats.totalOrders > 0 ? Math.round((orders.filter(o => o.status === 'delivered').length / stats.totalOrders) * 100) : 0}%
              </p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
