import { NextResponse } from 'next/server'
import { getSupabase } from '@/lib/supabase'
import { cookies } from 'next/headers'
import * as XLSX from 'xlsx'

export async function GET() {
  try {
    const cookieStore = await cookies()
    const adminToken = cookieStore.get('admin_token')?.value
    if (!adminToken) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const sb = getSupabase()
    if (!sb) return NextResponse.json({ error: 'DB not available' }, { status: 500 })

    const { data: session } = await sb.from('admin_sessions').select('store_id').eq('token', adminToken).single()
    if (!session) return NextResponse.json({ error: 'Invalid session' }, { status: 401 })

    const { data: orders } = await sb
      .from('orders')
      .select('*')
      .eq('store_id', session.store_id)
      .order('created_at', { ascending: false })

    const rows = (orders || []).map((o: any) => ({
      'Order ID': o.id?.slice(0, 8),
      'Customer Name': o.customer_name,
      'Phone': o.phone,
      'Governorate': o.governorate,
      'City': o.city,
      'Address': o.address,
      'Status': o.status,
      'Total (EGP)': o.total,
      'Items Count': o.items?.reduce((s: number, i: any) => s + (i.quantity || 1), 0) || 0,
      'Payment Method': o.payment_method,
      'Notes': o.notes || '',
      'Date': new Date(o.created_at).toLocaleDateString('en-US'),
    }))

    const wb = XLSX.utils.book_new()
    const ws = XLSX.utils.json_to_sheet(rows)
    ws['!cols'] = [
      { wch: 10 }, { wch: 25 }, { wch: 15 },
      { wch: 15 }, { wch: 15 }, { wch: 30 },
      { wch: 12 }, { wch: 12 }, { wch: 10 },
      { wch: 12 }, { wch: 20 }, { wch: 12 },
    ]
    XLSX.utils.book_append_sheet(wb, ws, 'Orders')

    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' })

    return new NextResponse(buf, {
      status: 200,
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="orders-export-${Date.now()}.xlsx"`,
      },
    })
  } catch (err) {
    console.error('Export error:', err)
    return NextResponse.json({ error: 'Export failed' }, { status: 500 })
  }
}
